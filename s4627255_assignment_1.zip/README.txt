README

just run the code and it will generate the plot, takes some time